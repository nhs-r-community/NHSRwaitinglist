

## TODO
# Add a function to work out the 92nd percentile
# Ensure that the date columns are real Date objects
# Ensure dates don't overlap
# work out capacity from two or more histograms
# estimate
# Create a similar plot with exponential distribution
# Input several dataframes
# WL to histogram
# Need a histogram format function ?


library(dplyr)
data <- read.csv("tom_data/20250515_top5_rtt_histogram_data.csv")
View(data)


library(ggplot2)

ggplot(data, aes(waiting_since, n)) +
  geom_col(aes(fill = ptl_type)) +
  facet_wrap(vars(specialty))

  # Filter for Gastroenterology and rename columns.
  df_gastro <- data[data$spec_code == 101 & data$ptl_type == "Non-admitted", ]
df_gastro$waiting_since <- as.Date(df_gastro$waiting_since)
df_gastro$arrival_before<- df_gastro$waiting_since + 6
df_gastro <- df_gastro %>%
  rename(arrival_since = waiting_since)
wl_hist <- df_gastro[ , c("arrival_before", "arrival_since", "n")]
rownames(wl_hist) <- NULL
View(wl_hist)


ggplot(wl_hist, aes(x = arrival_since, y = n)) +
  geom_col(aes(fill = arrival_before)) +
  labs(title = "Gastroenterology Waiting List Histogram",
       x = "Arrival Since",
       y = "Number of Patients") +
  coord_fixed(ratio = 1)

latest_date <- max(wl_hist$arrival_since, na.rm = TRUE)
cutoff_52 <- latest_date - 52 * 7  # 52 weeks
cutoff_18 <- latest_date - 18 * 7  # 18 weeks



# CHECK this...
library(tidyverse)   # just for date arithmetic convenience

# --- Make sure the date columns are real Date objects -------------
wl_hist <- wl_hist %>%
  mutate(across(c(arrival_since, arrival_before), as.Date))

# --- Sort from most-recent week to oldest -------------------------
wl_hist <- wl_hist %>% arrange(desc(arrival_since))

# --- Cumulative counts and 92 nd-percentile threshold -------------
total_patients <- sum(wl_hist$n, na.rm = TRUE)
p92_cut        <- 0.92 * total_patients              # numeric threshold

wl_hist <- wl_hist %>% mutate(cum_n = cumsum(n))

# first row whose cumulative count meets / exceeds the threshold
row92 <- wl_hist %>% filter(cum_n >= p92_cut) %>% slice(1)

# patients we still needed inside that row
needed_in_row <- p92_cut - (row92$cum_n - row92$n)

# proportion of that weekly bin required
prop_in_bin   <- needed_in_row / row92$n

# exact 92 nd-percentile date ≈ start-of-bin + prop * 7 days
date_p92 <- row92$arrival_since + days(round(prop_in_bin * 7))
ggplot(wl_hist, aes(x = arrival_since, y = n)) +
  geom_col(aes(fill = arrival_before)) +
  labs(
    title = "Gastroenterology Waiting List Histogram",
    x = "Arrival Since",
    y = "Number of Patients",
    fill = "Arrived Before?"
  ) +
  # Vertical lines at 52 and 18 weeks before latest date
  geom_vline(xintercept = as.numeric(cutoff_52), linetype = "dashed", color = "red") +
  geom_vline(xintercept = as.numeric(cutoff_18), linetype = "dashed", color = "blue") +
  geom_vline(xintercept = as.numeric(date_p92), linetype = "dashed", color = "purple") +
  # Annotate lines (optional)
  annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
           angle = 90, vjust = -0.4, hjust = 1, color = "red") +
  annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
           angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
  annotate("text", x = date_p92, y = max(wl_hist$n), label = "92 percentile",
           angle = 90, vjust = -0.4, hjust = 1, color = "purple") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  coord_fixed(ratio = 1)

################# GETS DEMAND STATS `######################`
df_referrals <-  wl_hist[which.max(wl_hist$arrival_before),]

df_referrals$days <- df_referrals$arrival_before[1]+1 - df_referrals$arrival_since[1]

referral_stats <- data.frame(
  "demand_weekly" = df_referrals$days[1] / 7,
  "demand_daily" = df_referrals$days[1],
  "demand_cov" = 1,
  "demand_count" = df_referrals$n[1]
)

################ Find number served ######################

set.seed(123)  # Optional: for reproducibility

# 1. Subtract Poisson(5) random numbers, clamp to 0
wl_hist2 <- wl_hist %>%
  mutate(
    n = n - rpois(n(), lambda = 5),
    n = ifelse(n < 0, 0, n)
  )

# 2. Create the new row
new_row <- tibble::tibble(
  arrival_before = as.Date("2025-05-22"),
  arrival_since  = as.Date("2025-05-16"),
  n              = 375
)

# 3. Add it to the data
wl_hist2 <- bind_rows(wl_hist2, new_row)

# Optional: sort chronologically if needed
wl_hist2 <- wl_hist2 %>%
  arrange(desc(arrival_since))

rownames(wl_hist) <- NULL
rownames(wl_hist2) <- NULL



# Step 1: Rename for clarity
wl_hist1_clean <- wl_hist1 %>%
  rename(
    n_hist1 = n,
    arrival_before_hist1 = arrival_before
  )

wl_hist2_clean <- wl_hist2 %>%
  rename(
    n_hist2 = n,
    arrival_before_hist2 = arrival_before
  )

# Step 2: Full join and handle missing data
comparison <- full_join(wl_hist1_clean, wl_hist2_clean, by = "arrival_since") %>%
  mutate(
    n_hist1 = replace_na(n_hist1, 0),
    n_hist2 = replace_na(n_hist2, 0),
    # Step 3: Merge the arrival_before columns using coalesce
    arrival_before = coalesce(arrival_before_hist1, arrival_before_hist2),
    change = n_hist2 - n_hist1
  ) %>%
  # Optional: tidy up column order
  select(
    arrival_since,
    arrival_before,
    n_hist1,
    n_hist2,
    change
  ) %>%
  arrange(arrival_since)

# View result
print(comparison)


# Define geometric parameter p
p <- 1-exp(log(0.08) / 18)

# Add row number and geometric probabilities
wl_hist2 <- wl_hist %>%
  mutate(
    row_number = row_number(),  # treat row number as "week k"
    geom_prob = round(1080*dgeom(row_number - 1, prob = p))
  )

View(wl_hist2)

#total_patients <- 1080
#wl_hist <- wl_hist %>%
#  mutate(
#    row_number = row_number(),
#    p = 1- exp(log(0.8) / 18),
#    geom_prob = dgeom(row_number - 1, prob = p),
#    geom_scaled = geom_prob * total_patients  # scaled to total observed
#  )

wl_hist <- wl_hist2

geom_scaled <- 1

library(ggplot2)

ggplot(wl_hist, aes(x = arrival_since)) +
  # Observed histogram
  geom_col(aes(y = n, fill = "Observed"), alpha = 0.7, position = "identity") +

  # Geometric model (scaled)
  geom_col(aes(y = geom_prob, fill = "Geometric Model"), alpha = 0.5, position = "identity") +

  # Vertical lines
  geom_vline(xintercept = as.numeric(cutoff_52), linetype = "dashed", color = "red") +
  geom_vline(xintercept = as.numeric(cutoff_18), linetype = "dashed", color = "blue") +
  geom_vline(xintercept = as.numeric(date_p92), linetype = "dashed", color = "purple") +

  # Annotations
  annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
           angle = 90, vjust = -0.4, hjust = 1, color = "red") +
  annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
           angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
  annotate("text", x = date_p92, y = max(wl_hist$n), label = "92 percentile",
           angle = 90, vjust = -0.4, hjust = 1, color = "purple") +

  # Labels and themes
  labs(
    title = "Observed vs. Geometric Model Histogram",
    x = "Arrival Since",
    y = "Number of Patients",
    fill = "Histogram Type"
  ) +
  scale_fill_manual(values = c("Observed" = "steelblue", "Geometric Model" = "orange")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

######### TEST TOM's FUNCTIONS #################

library(dplyr)
data <- read.csv("tom_data/20250515_top5_rtt_histogram_data.csv")
View(data)

library(ggplot2)

ggplot(data, aes(waiting_since, n)) +
  geom_col(aes(fill = ptl_type)) +
  facet_wrap(vars(specialty))


df_urology <- data[data$spec_code == 101 & data$ptl_type == "Non-admitted", ]
df_urology$waiting_since <- as.Date(df_urology$waiting_since)
df_urology$arrival_before<- df_urology$waiting_since + 6
df_urology <- df_urology %>%
  rename(arrival_since = waiting_since)

df_gastro <- data[data$spec_code == 301 & data$ptl_type == "Non-admitted", ]
df_gastro$waiting_since <- as.Date(df_gastro$waiting_since)
df_gastro$arrival_before<- df_gastro$waiting_since + 6
df_gastro <- df_gastro %>%
  rename(arrival_since = waiting_since)


########### TEST aggregate_histogram ############

histogram <- tibble::tibble(
  arrival_since = as.Date(c("2024-06-01", "2024-06-01", "2024-06-02", "2024-06-02", "2024-06-03")),
  category = c("A", "B", "A", "B", "A"),
  n = c(10, 5, 20, 15, 7),
  arrival_before = as.Date(c("2024-06-01", "2024-06-01", "2024-06-02", "2024-06-02", "2024-06-03"))
)

if ("arrival_before" %in% colnames(histogram)) {
  result <- histogram |>
    dplyr::group_by(arrival_since, arrival_before) |>
    dplyr::summarise(n = sum(n), .groups = "drop")
} else {
  result <- histogram |>
    dplyr::group_by(arrival_since) |>
    dplyr::summarise(n = sum(n), .groups = "drop")
}

#result <- aggregate_histogram(histogram)
View(result)

histogram <- data.frame(
  arrival_since = rep(c("2024-01-01", "2024-01-02"), each = 5),
  arrival_before = rep(c("2024-01-10", "2024-01-11"), each = 5),
  category = rep(c("A", "B"), times = 5),
  type = rep(c("X", "Y", "X", "Y", "X"), 2),
  n = c(10, 5, 7, 3, 2, 8, 6, 4, 1, 9)
)

View(histogram)

# Aggregate by arrival_since and category
result1 <- aggregate_histogram(histogram, group_columns = "category")
print(result1)

# Aggregate by arrival_since, category, and type
result2 <- aggregate_histogram(histogram, group_columns = c("category", "type"))
print(result2)


############### TEST sim_exponential_histogram ###############

# Example usage of sim_exponential_histogram

# Simulate a 12-week waiting list ending on 2024-06-01 with rate 0.2
sim_hist <- sim_exponential_histogram(weeks = 12, end_date = as.Date("2024-06-01"), rate = 0.2)
print(sim_hist)

############### TEST wl_join_hist ###############


############### TEST wl_wait_time ###############

wl_wait_time <- function(waiting_list, referral_index, removal_index, end_date) {
    waiting_patients <-
        waiting_list[which((waiting_list[, removal_index] > end_date | is.na(waiting_list[, removal_index])) &
                                                waiting_list[, referral_index] <= end_date), ]
    wait_times <-
        as.numeric(end_date) - as.numeric(waiting_patients[, referral_index])
    mean(wait_times)
}

start_date <- as.Date("2024-01-01")
end_date <- as.Date("2024-03-31")
referral_index <- 1
removal_index <- 2

waiting_list <- wl_simulator(start_date,end_date, 10, 5)

wl_wait_time(waiting_list, referral_index, removal_index, end_date) 
############## CREATE wl_stats_hist ##############

View(waiting_list)


mean_removal_referral <- waiting_list %>%
  filter(!is.na(Referral) & !is.na(Removal)) %>%
  mutate(diff_days = as.numeric(Removal - Referral)) %>%
  summarise(mean_diff = mean(diff_days)) %>%
  pull(mean_diff)

print(mean_removal_referral)

end_date <- as.Date("2024-03-30")
referral_index <- 1
removal_index <- 2

wl_stats(waiting_list)
wl_mean_wait_age(waiting_list, referral_index, removal_index, end_date)


########### wl_mean_wait_age_hist ###############

end_date <- as.Date("2025-05-15")

# Calculate mean wait (in days) with reference to end_date using wl_hist
mean_wait_hist <- {
  wl_hist %>%
    mutate(
      wait_days = as.numeric(end_date - ((as.numeric(arrival_since) + as.numeric(arrival_before)) / 2))  ) %>%
    summarise(
      mean_wait = sum(wait_days * n) / sum(n)
    ) %>%
    pull(mean_wait)
}

print(mean_wait_hist)

wl_mean_wait_age_hist(wl_hist, end_date)

wl_stats_hist(wl_hist1, wl_hist2,end_date = end_date,target_wait = 18)

