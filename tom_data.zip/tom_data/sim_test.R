# Load the NHSRwaitinglist package
library(NHSRwaitinglist)
library(ggplot2)
library(dplyr, warn.conflicts = FALSE)

library(purrr)

set.seed(123)

wl <- wl_simulator(
  start_date = "2014-03-01",
  end_date = "2022-03-31",
  demand = 30, # simulating 10 patient arrivals per week
  capacity = 27 # simulating 9 patients being treated per week
)

wl2 <- wl_simulator(
  start_date = "2022-03-31",
  end_date = "2022-09-30",
  demand = 30,
  capacity = 61.15,
  waiting_list = wl
)

wl3 <- wl_simulator(
  start_date = "2022-09-30",
  end_date = "2030-09-30",
  demand = 30,
  capacity = 30.38,
  waiting_list = wl2
)

simulations <- map(1:1000, ~ wl_simulator(
  start_date = "2022-09-30",
  end_date = "2030-09-30",
  demand = 30,
  capacity = 30.38,
  waiting_list = wl2
))

queue_sizes <- map(simulations, wl_queue_size)
percentiles <- map_dfr(queue_sizes, ~ .x %>% select(dates, queue_size), .id = "simulation") %>%
  group_by(dates) %>%
  summarise(
    percentile_90 = quantile(queue_size, 0.90, na.rm = TRUE),
    median = quantile(queue_size, 0.5, na.rm = TRUE),
    percentile_10 = quantile(queue_size, 0.10, na.rm = TRUE)
  )

qs <- wl_queue_size(wl3)
View(tail(qs, 1000))

# Convert qs to a data frame for ggplot compatibility
qs_df <- as.data.frame(qs)

qs_df$date <- as.Date(qs_df$date) # Ensure the date column is in Date format
qs_df <- qs_df %>% filter(date > as.Date("2022-03-31"))

View(qs_df)

# Merge percentiles with qs_df for plotting
percentiles <- percentiles %>% rename(date = dates)
plot_data <- left_join(qs_df, percentiles, by = "date")

# Filter data to include only dates up to September 27th
plot_data <- plot_data %>% filter(date > as.Date("2022-07-31"))

# Plot the queue size over time with percentiles
ggplot(plot_data, aes(x = date)) +
  geom_line(aes(y = queue_size, color = "Queue Size"), color = "black") +
  geom_ribbon(aes(ymin = percentile_10, ymax = percentile_90), fill = "#e4e4e4", alpha = 0.5) + # nolint
  geom_line(aes(y = percentile_90), color = "#d6d5d5") +
  geom_line(aes(y = median), color = "#d6d5d5") + # Change median line color to lightgrey
  geom_line(aes(y = percentile_10), color = "#d6d5d5") +
  labs(
    title = "Queue Size Over Time with Percentiles",
    x = "Date",
    y = "Queue Size",
    color = "Legend"
  ) +
  theme_minimal()  +
    scale_y_continuous(limits = c(0, 650))