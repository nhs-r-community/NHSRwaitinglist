library(tidyverse)
files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
View(files)
source("R/aggregate_histogram.R")
sapply(files, source)

data1 <- read.csv("tom_data/20250515_top5_rtt_histogram_data.csv")
data1 <- data1 %>%
    rename(arrival_since = waiting_since) %>%
    mutate(arrival_before = as.Date(arrival_since) + 6) %>%
    relocate(arrival_before, .after = 2)
data1 <- data1 %>%
    rename(report_date = snapshot_date)
data2 <- read.csv("tom_data/20250522_top5_rtt_histogram_data.csv")

View(data1)
View(data2)

wl_hist1 <- data1[data1$spec_code == 101 & data1$ptl_type == "Non-admitted", ]
wl_hist2 <- data2[data2$spec_code == 101 & data2$ptl_type == "Non-admitted", ]
wl_hist1 <- wl_hist1[ , c("report_date", "arrival_before", "arrival_since", "n")]
wl_hist2 <- wl_hist2[ , c("report_date", "arrival_before", "arrival_since", "n")]

View(wl_hist1)
View(wl_hist2)

wl_stats_hist(wl_hist1, wl_hist2)
specialties <- intersect(unique(data1$specialty), unique(data2$specialty))
all_stats <- purrr::map_dfr(specialties, function(specialty) {
    wl_hist1 <- data1[data1$specialty == specialty & data1$ptl_type == "Non-admitted", ]
    wl_hist2 <- data2[data2$specialty == specialty & data2$ptl_type == "Non-admitted", ]
    wl_hist1 <- wl_hist1[ , c("report_date", "arrival_before", "arrival_since", "n")]
    wl_hist2 <- wl_hist2[ , c("report_date", "arrival_before", "arrival_since", "n")]
    stats <- wl_stats_hist(wl_hist1, wl_hist2)
    stats$specialty <- specialty
    stats
})
View(all_stats)
spec_labels <- data1 %>%
    select(specialty) %>%
    distinct()
print(spec_labels)

all_stats <- spec_labels %>%
    left_join(all_stats, by = "specialty")

all_stats
all_stats <- all_stats %>%
    mutate(ratio = queue_size / target_queue_size) %>%
    relocate(ratio, .after = target_queue_size)

View(all_stats)

library(DT)

dt <- datatable(
    all_stats,
    filter = "top",         # Adds dropdowns for filtering at the top of each column
    options = list(
        pageLength = 20,      # Number of rows per page
        autoWidth = TRUE
    ),
    rownames = FALSE
) %>%
formatStyle(
        'load_too_big',
        backgroundColor = styleEqual(
                c(TRUE, FALSE),
                c('red', 'green')
        )
) %>%
formatStyle(
        'queue_too_big',
        backgroundColor = styleEqual(
                c(TRUE, FALSE),
                c('red', 'green')
        )
)
# In VSCode, you cannot use View() to open data frames as in RStudio.
# Instead, you can print the head of the data frame in the terminal:
browseURL("all_stats_table.html")
# Or use the DT datatable as you already do, and open the resulting HTML file in your browser.

saveWidget(dt, "all_stats_table.html")

all_stats$pressure <- as.numeric(all_stats$pressure)
