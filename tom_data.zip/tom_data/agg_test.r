library(testthat)
library(dplyr)

test_that("aggregate_histogram aggregates over categories", {
  # Sample histogram with categories
  histogram <- tibble::tibble(
    arrival_since = as.Date(c("2024-06-01", "2024-06-01", "2024-06-02", "2024-06-02", "2024-06-03")),
    category = c("A", "B", "A", "B", "A"),
    n = c(10, 5, 20, 15, 7)
  )
  result <- aggregate_histogram(histogram)
  
  expect_true(is.data.frame(result))
  expect_equal(colnames(result), c("arrival_since", "n"))
  expect_equal(nrow(result), 3)
  expect_equal(result$n[result$arrival_since == as.Date("2024-06-01")], 15)
  expect_equal(result$n[result$arrival_since == as.Date("2024-06-02")], 35)
  expect_equal(result$n[result$arrival_since == as.Date("2024-06-03")], 7)
})

test_that("aggregate_histogram works with empty input", {
  histogram <- tibble::tibble(
    arrival_since = as.Date(character()),
    category = character(),
    n = integer()
  )
  result <- aggregate_histogram(histogram)
  expect_true(is.data.frame(result))
  expect_equal(nrow(result), 0)
})

test_that("aggregate_histogram works with single row", {
  histogram <- tibble::tibble(
    arrival_since = as.Date("2024-06-01"),
    category = "A",
    n = 42
  )
  result <- aggregate_histogram(histogram)
  expect_equal(nrow(result), 1)
  expect_equal(result$n, 42)
})

test_that("aggregate_histogram handles missing values in n", {
  histogram <- tibble::tibble(
    arrival_since = as.Date(c("2024-06-01", "2024-06-01")),
    category = c("A", "B"),
    n = c(10, NA)
  )
  result <- aggregate_histogram(histogram)
  expect_equal(result$n[result$arrival_since == as.Date("2024-06-01")], 10)
})
