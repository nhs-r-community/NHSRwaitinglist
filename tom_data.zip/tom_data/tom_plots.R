
# TODO: make this script into a function that creates a histogram plot for all specialties

library(tidyverse)
data <- read.csv("tom_data/20250522_top5_rtt_histogram_data.csv")
View(data)
files <- list.files("R", pattern = "\\.R$", full.names = TRUE)
View(files)
source("R/aggregate_histogram.R")
sapply(files, source)

length(unique(data$specialty))

library(ggplot2)

# Filter for Gastroenterology and rename columns.
df_gastro <- data[data$spec_code == 101 & data$ptl_type == "Non-admitted", ]
df_gastro$waiting_since <- as.Date(df_gastro$waiting_since)
df_gastro$arrival_before <- df_gastro$waiting_since + 6
df_gastro <- df_gastro %>%
    rename(arrival_since = waiting_since)
wl_hist <- df_gastro[ , c("report_date", "arrival_before", "arrival_since", "n")]
rownames(wl_hist) <- NULL
View(wl_hist)

# Create a histogram for the Gastroenterology waiting list.
wl_hist$weeks_waiting <- round(as.numeric(difftime(wl_hist$report_date, wl_hist$arrival_since, units = "weeks")))
wl_hist <- wl_hist[, c("report_date", "arrival_before", "arrival_since", "weeks_waiting", "n")]
View(wl_hist)

cutoff_52 <- 52
cutoff_18 <- 18

# TODO: you have a function for this, in sebs code use it

# --- Make sure the date columns are real Date objects -------------
wl_hist <- wl_hist %>%
  mutate(across(c(arrival_since, arrival_before), as.Date))

# --- Sort from most-recent week to oldest -------------------------
wl_hist <- wl_hist %>% arrange(desc(arrival_since))

# --- Cumulative counts and 92 nd-percentile threshold -------------
total_patients <- sum(wl_hist$n, na.rm = TRUE)
p92_cut        <- 0.92 * total_patients              # numeric threshold

wl_hist <- wl_hist %>% mutate(cum_n = cumsum(n))

# first row whose cumulative count meets / exceeds the threshold
row92 <- wl_hist %>% filter(cum_n >= p92_cut) %>% slice(1)


# patients we still needed inside that row
needed_in_row <- p92_cut - (row92$cum_n - row92$n)

# proportion of that weekly bin required
prop_in_bin   <- needed_in_row / row92$n

# exact 92 nd-percentile date ≈ start-of-bin + prop * 7 days
date_p92 <- row92$arrival_since + days(round(prop_in_bin * 7))
weeks_p92 <- round(as.numeric(difftime(row92$report_date, date_p92, units = "weeks")))



# Create the histogram plot with aspect ratio 2:1 (width:height).
ggplot(wl_hist, aes(x = weeks_waiting, y = n)) +
    geom_col(fill = "#4682B4") +  # matt blue (steelblue) # nolint
    labs(title = "Gastroenterology Waiting List Histogram",
         x = "Weeks Waiting",
         y = "Number of Patients") +
coord_fixed(ratio = 0.15) +
# Vertical lines at 52, 18, and 92nd percentile weeks before latest date
geom_vline(
  xintercept = as.numeric(cutoff_52),
  linetype = "dashed",
  color = "red"
) +
geom_vline(
  xintercept = as.numeric(cutoff_18),
  linetype = "dashed",
  color = "blue"
) +
geom_vline(
  xintercept = as.numeric(weeks_p92),
  linetype = "dashed",
  color = "orange"
) +
# Annotate lines (optional)
annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "red") +
annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
annotate("text", x = weeks_p92, y = max(wl_hist$n), label = "92nd percentile",
         angle = 90, vjust = -0.4, hjust = 1, color = "orange") +
theme_minimal() +
theme(axis.text.x = element_text(angle = 0, hjust = 1))

q_target <- calc_target_queue_size(demand = (wl_hist$n[1]+wl_hist$n[2]+wl_hist$n[3])/3, target_wait = 18, factor = 2.52)
# Define geometric parameter p
p <- 1-exp(log(0.08) / 18)

# Add row number and geometric probabilities
wl_hist <- wl_hist %>%
  mutate(
    row_number = row_number(),  # treat row number as "week k"
    geom_prob = round(q_target*dgeom(row_number - 1, prob = p))
  )

View(wl_hist)


# Create the histogram plot with aspect ratio 2:1 (width:height).
ggplot(wl_hist, aes(x = weeks_waiting, y = n)) +
    geom_col(fill = "#4682B4") +  # matt blue (steelblue) # nolint
    labs(title = "Gastroenterology Waiting List Histogram",
         x = "Weeks Waiting",
         y = "Number of Patients") +
coord_fixed(ratio = 0.15) +
# Vertical lines at 52, 18, and 92nd percentile weeks before latest date
geom_vline(
  xintercept = as.numeric(cutoff_52),
  linetype = "dashed",
  color = "red"
) +
geom_vline(
  xintercept = as.numeric(cutoff_18),
  linetype = "dashed",
  color = "blue"
) +
geom_vline(
  xintercept = as.numeric(weeks_p92),
  linetype = "dashed",
  color = "orange"
) +
# Annotate lines (optional)
annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "red") +
annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
annotate("text", x = weeks_p92, y = max(wl_hist$n), label = "92nd percentile",
         angle = 90, vjust = -0.4, hjust = 1, color = "orange") +
theme_minimal() +
theme(axis.text.x = element_text(angle = 0, hjust = 1))


# Create the histogram plot with aspect ratio 2:1 (width:height).
ggplot(wl_hist, aes(x = weeks_waiting, y = n)) +
    geom_col(fill = "#4682B4") +  # matt blue (steelblue) # nolint
    labs(title = "Gastroenterology Waiting List Histogram",
         x = "Weeks Waiting",
         y = "Number of Patients") +
coord_fixed(ratio = 0.15) +
# Vertical lines at 52, 18, and 92nd percentile weeks before latest date
geom_vline(
  xintercept = as.numeric(cutoff_52),
  linetype = "dashed",
  color = "red"
) +
geom_vline(
  xintercept = as.numeric(cutoff_18),
  linetype = "dashed",
  color = "blue"
) +
geom_vline(
  xintercept = as.numeric(weeks_p92),
  linetype = "dashed",
  color = "orange"
) +
# Annotate lines (optional)
annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "red") +
annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
         angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
annotate("text", x = weeks_p92, y = max(wl_hist$n), label = "92nd percentile",
         angle = 90, vjust = -0.4, hjust = 1, color = "orange") +
theme_minimal() +
theme(axis.text.x = element_text(angle = 0, hjust = 1))

# Add plot: x = weeks_waiting, y = geom_prob
ggplot(wl_hist, aes(x = weeks_waiting, y = geom_prob)) +
    geom_col(fill = "#FFA500") +  # orange
    labs(title = "Geometric Target Distribution",
         x = "Weeks Waiting",
         y = "Target Number of Patients (Geometric)") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0, hjust = 1))


ggplot(wl_hist, aes(x = weeks_waiting)) +
    geom_col(aes(y = n, fill = "Actual"), color = NA) +
    geom_col(aes(y = geom_prob, fill = "Geometric Target"), color = NA, alpha = 0.4) +
    scale_fill_manual(
        name = "Legend",
        values = c("Actual" = "#4682B4", "Geometric Target" = "#FFA500")
    ) +
    labs(
        title = "Gastroenterology Waiting List: Actual vs Geometric Target",
        x = "Weeks Waiting",
        y = "Number of Patients"
    ) +
    coord_fixed(ratio = 0.15) +
    geom_vline(xintercept = as.numeric(cutoff_52), linetype = "dashed", color = "red") +
    geom_vline(xintercept = as.numeric(cutoff_18), linetype = "dashed", color = "blue") +
    geom_vline(xintercept = as.numeric(weeks_p92), linetype = "dashed", color = "orange") +
    annotate("text", x = cutoff_52, y = max(wl_hist$n), label = "52 weeks ago",
             angle = 90, vjust = -0.4, hjust = 1, color = "red") +
    annotate("text", x = cutoff_18, y = max(wl_hist$n), label = "18 weeks ago",
             angle = 90, vjust = -0.4, hjust = 1, color = "blue") +
    annotate("text", x = weeks_p92, y = max(wl_hist$n), label = "92nd percentile",
             angle = 90, vjust = -0.4, hjust = 1, color = "orange") +
    theme_minimal() +
    theme(
        axis.text.x = element_text(angle = 0, hjust = 1),
        legend.position = c(0.98, 0.98),
        legend.justification = c("right", "top")
    )





    ############# MULTIPLE PLOTS ####################


    # Filter for Gastroenterology and rename columns.
df_gastro <- data[data$spec_code == 330 & data$ptl_type == "Non-admitted", ]
df_gastro$waiting_since <- as.Date(df_gastro$waiting_since)
df_gastro$arrival_before <- df_gastro$waiting_since + 6
df_gastro <- df_gastro %>%
    rename(arrival_since = waiting_since)
wl_hist <- df_gastro[ , c("report_date", "arrival_before", "arrival_since", "n")]
rownames(wl_hist) <- NULL
View(wl_hist)

vis_plot_hist(wl_hist, target = 18, percentage = 92)
    view(data)

    wl_stats_hist(wl_hist)
